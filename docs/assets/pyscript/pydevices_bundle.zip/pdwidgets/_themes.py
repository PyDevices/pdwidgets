# SPDX-FileCopyrightText: 2024 Brad Barnett
#
# SPDX-License-Identifier: MIT
"""
Themes used by the pdwidgets library.  The IconTheme class is used to manage icons and the ColorTheme class is used to manage colors.
"""

from palettes import get_palette  # noqa: F401

from ._constants import ICON_SIZE


class IconTheme:
    """Resolve shipped icon assets as importable ``pdwidgets.icons.*`` modules."""

    _suffix = "dp"
    _pkg = "pdwidgets.icons"
    _home = "home_filled_"
    _up_arrow = "keyboard_arrow_up_"
    _down_arrow = "keyboard_arrow_down_"
    _left_arrow = "keyboard_arrow_left_"
    _right_arrow = "keyboard_arrow_right_"
    _check_box_checked = "check_box_"
    _check_box_unchecked = "check_box_outline_blank_"
    _radio_button_checked = "radio_button_checked_"
    _radio_button_unchecked = "radio_button_unchecked_"
    _toggle_on = "toggle_on_"
    _toggle_off = "toggle_off_"
    _close = "close_"
    _add = "add_"
    _remove = "remove_"
    _info = "info_"
    _warning = "warning_"
    _error = "error_"
    _dropdown = "expand_more_"
    _menu = "menu_"

    def __init__(self, path=None):
        """Create an icon theme that resolves shipped ``pdwidgets.icons`` modules.

        Module stems look like ``home_filled_36dp`` (sizes from
        :data:`~pdwidgets.ICON_SIZE`: 18, 24, 36, 48). Access icons via
        attribute callables such as ``icon_theme.home(ICON_SIZE.LARGE)``.

        Args:
            path (str): Accepted for call-site compatibility and ignored; icons are
                always loaded by module name.

        Example:
            >>> from pdwidgets import IconTheme, ICON_SIZE, IconButton
            >>> icon_theme = IconTheme()
            >>> IconButton(screen, icon_file=icon_theme.home(ICON_SIZE.LARGE))
        """
        del path  # retained for call-site compatibility

    def _icon(self, name, size):
        if size not in ICON_SIZE:
            raise ValueError("Invalid icon size.")
        stem = f"{getattr(self, '_' + name)}{size}{self._suffix}"
        return f"{self._pkg}.{stem}"

    def __getattr__(self, name):
        """Return a ``(size) -> module_path`` callable for a named icon.

        Args:
            name: Icon stem without size or ``dp`` suffix (for example
                ``"home"``, ``"menu"``, ``"close"``).

        Returns:
            A callable that takes an :data:`~pdwidgets.ICON_SIZE` value and
            returns the fully qualified icon module path.

        Raises:
            AttributeError: If ``name`` is private (starts with ``_``).
        """
        if name.startswith("_"):
            raise AttributeError(name)
        return lambda size: self._icon(name, size)


icon_theme = IconTheme()


class ColorTheme:
    """
    Semantic color theme for pdwidgets.

    The default palette is a friendly, slightly colorful "early color Mac" look:
    a soft warm-cream background, near-black ink, and a small set of muted
    pastel accents (slate blue, warm gold, soft coral) with warm greys for
    inactive states — chunky-but-clean rather than a saturated Material blue.

    Colors are computed through ``pal.color565`` so the display's byteswap is
    respected. Widgets reference these slots by name, so re-skinning the whole
    toolkit is a matter of assigning different values here (or after
    construction via ``display.color_theme``).

    Args:
        pal (Palette): A palette object from the ``palettes`` package; used only
            for its ``color565`` conversion (and byteswap handling).
    """

    def __init__(self, pal):
        """Build semantic color slots from a palette's ``color565`` converter.

        Args:
            pal (Palette): A :class:`~palettes.Palette` (or compatible) object used only
                for ``color565`` conversion and byteswap handling.
        """
        c = pal.color565
        # Neutrals
        self.background = c(0xF2EEE3)  # warm cream page
        self.on_background = c(0x2A2A30)  # near-black ink
        self.surface = c(0xFBF8F0)  # card / raised surface
        self.on_surface = c(0x2A2A30)
        self.surface_variant = c(0xE7E1D3)  # subtle sunken panel
        self.outline = c(0xB6AE9C)  # hairline borders
        self.shadow = c(0xCAC3B4)  # cheap fake drop shadow (warm grey)
        # Accents
        self.primary = c(0x4E6E8E)  # muted slate blue
        self.on_primary = c(0xFFFFFF)
        self.primary_variant = c(0x3A536B)  # darker slate (pressed / shadow)
        self.secondary = c(0xE6B24C)  # warm muted gold
        self.on_secondary = c(0x2A2A30)
        self.secondary_variant = c(0xCC7A5C)  # soft coral (third accent)
        self.tertiary = c(0x9E978A)  # warm grey (inactive)
        self.on_tertiary = c(0x2A2A30)
        self.tertiary_variant = c(0xC4BDAD)  # light warm grey
        # Status
        self.error = c(0xC1544A)  # muted brick red
        self.on_error = c(0xFFFFFF)
        self.success = c(0x5E9E6E)  # muted green (status dots, badges)
        self.on_success = c(0xFFFFFF)
        self.transparent = False
        # Priority B controls (map widgets to these; no hard-coded RGB)
        # Chip compact filters
        self.chip = self.surface_variant
        self.chip_selected = self.primary
        self.on_chip = self.on_surface
        self.on_chip_selected = self.on_primary
        # Modal sheets / drawers / menus (opaque scrims — no alpha on MCU FB)
        self.sheet_scrim = self.shadow
        self.menu_surface = self.surface
        self.on_menu = self.on_surface
        # SegmentedControl / Accordion chrome
        self.segment = self.surface_variant
        self.segment_selected = self.primary
        self.on_segment = self.on_surface
        self.on_segment_selected = self.on_primary
